import os
import json
import gzip
import hashlib
import base64
import asyncio
import socket
import ipaddress
from aiohttp import web, ClientSession, ClientTimeout, TCPConnector

TARGET_BASE_URL = "https://dl-bs.ggpolarbear.com/live/ABHotUpdates/"
VER_PHP_URL = "https://version.ggwhitehawk.com/live/ver.php"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PORT = 8080

SERVE_CACHE_RES = "cache_res2"
REGISTERED_FILE = os.path.join(BASE_DIR, "registered_ips.json")
VERIFIED_FILE = os.path.join(BASE_DIR, "verified_ips.json")
ENGAGED_FILE = os.path.join(BASE_DIR, "engaged_ips.json")

YT_URL = "https://youtube.com/@zaru_exe?si=VGZw3cZDbpfD4Ann"
TG_URL = "https://t.me/+HZmbe_GbIf0xZGVl"
DEV_UPLOAD_URL = "https://devuploads.com"

ANTI_BAN_OVERRIDES = {
    "FFAntihackDefenceLevel": {"var_type": "string", "var_value": "0"},
    "FFAntihackLightInitOnThread": {"var_type": "bool", "var_value": "false"},
    "FFAntihackEmulatorCheckDisbaledClientVariant": {"var_type": "string", "var_value": ""},
    "FFAntihackSDKDetailEncryptBySHA1": {"var_type": "bool", "var_value": "false"},
    "EnableFFAntihackInfoExtra": {"var_type": "bool", "var_value": "false"},
    "EarlyInitGGP": {"var_type": "bool", "var_value": "false"},
    "DisableGinInfoSend": {"var_type": "int", "var_value": "1"},
    "GinInfoBRAliveThreshold": {"var_type": "int", "var_value": "0"},
    "AntiHackResetSubgameInterval": {"var_type": "int", "var_value": "0"},
    "FFANTIHACKEXT_SPLIT_THRESHOLD": {"var_type": "int", "var_value": "0"},
    "EnablePlatformCheck": {"var_type": "bool", "var_value": "false"},
    "EnableSupCheck": {"var_type": "bool", "var_value": "false"},
    "EnableMMKPlatformCheck": {"var_type": "bool", "var_value": "false"},
}

SPEED_HACK_OVERRIDES = {
    "RunSpeed": {"var_type": "float", "var_value": "3.0"},
    "DashSpeedScale": {"var_type": "float", "var_value": "3.0"},
}

def get_overrides():
    overrides = dict(ANTI_BAN_OVERRIDES)
    overrides.update(SPEED_HACK_OVERRIDES)
    return overrides

_registered = set()

def load_registered():
    global _registered
    try:
        with open(REGISTERED_FILE, "r") as f:
            _registered = set(json.load(f))
    except Exception:
        _registered = set()

def save_registered():
    try:
        with open(REGISTERED_FILE, "w") as f:
            json.dump(sorted(_registered), f, indent=2)
    except Exception as e:
        print(f"[ERROR] save registered: {e}")

def is_registered(ip):
    return ip in _registered

def register_ip(ip):
    _registered.add(ip)
    save_registered()

def unregister_ip(ip):
    _registered.discard(ip)
    save_registered()

_verified = set()

def load_verified():
    global _verified
    try:
        with open(VERIFIED_FILE, "r") as f:
            _verified = set(json.load(f))
    except Exception:
        _verified = set()

def save_verified():
    try:
        with open(VERIFIED_FILE, "w") as f:
            json.dump(sorted(_verified), f, indent=2)
    except Exception as e:
        print(f"[ERROR] save verified: {e}")

def is_verified(ip):
    return ip in _verified

def mark_verified(ip):
    _verified.add(ip)
    save_verified()

_engaged = {}

def load_engaged():
    global _engaged
    try:
        with open(ENGAGED_FILE, "r") as f:
            _engaged = json.load(f)
    except Exception:
        _engaged = {}

def save_engaged():
    try:
        with open(ENGAGED_FILE, "w") as f:
            json.dump(_engaged, f, indent=2)
    except Exception as e:
        print(f"[ERROR] save engaged: {e}")

def mark_engaged(ip, kind):
    _engaged.setdefault(ip, {})[kind] = True
    save_engaged()

def engagement(ip):
    d = _engaged.get(ip, {})
    return {"yt": bool(d.get("yt")), "tg": bool(d.get("tg")), "upload": bool(d.get("upload"))}

def steps_done(ip):
    e = engagement(ip)
    return e["yt"] and e["tg"] and e["upload"]

def is_valid_ip(ip):
    try:
        ipaddress.ip_address(ip.strip())
        return True
    except Exception:
        return False

def client_ip(request):
    for h in ("CF-Connecting-IP", "X-Forwarded-For", "X-Real-IP"):
        val = request.headers.get(h)
        if val:
            return val.strip().split(",")[0].strip()
    return request.remote or ""

def sha1_b64(data):
    return base64.b64encode(hashlib.sha1(data).digest()).decode()

def cache_res_data():
    path = os.path.join(BASE_DIR, SERVE_CACHE_RES)
    if os.path.exists(path):
        with open(path, "rb") as f:
            return f.read()
    return None

def ensure_cache_res_gzip():
    path = os.path.join(BASE_DIR, SERVE_CACHE_RES)
    if not os.path.exists(path):
        print(f"[!] {SERVE_CACHE_RES} missing")
        return
    with open(path, "rb") as f:
        data = f.read()
    if data and not data.startswith(b"\x1f\x8b"):
        print(f"[WARN] {SERVE_CACHE_RES} not gzip - compressing once and saving to disk")
        with open(path, "wb") as f:
            f.write(gzip.compress(data))

def patch_fileinfo(original_text):
    lines = original_text.splitlines()
    new_lines = []
    cr_line = None
    gz_data = cache_res_data()
    if gz_data is not None:
        try:
            raw_data = gzip.decompress(gz_data)
            cr_line = f"cache_res,{sha1_b64(raw_data)},{len(raw_data)},0,{sha1_b64(gz_data)},{len(gz_data)},True,0"
        except Exception as e:
            print(f"[ERROR] cache_res patch failed: {e}")
    for line in lines:
        if cr_line is not None and line.startswith("cache_res,"):
            new_lines.append(cr_line)
        else:
            new_lines.append(line)
    return "\n".join(new_lines)

def modify_ver_response(response_text, cdn_self, ip):
    try:
        data = json.loads(response_text)
        data["abhotupdate_check"] = "cache_res"
        overrides = get_overrides()
        if overrides:
            gamevar = data.get("gamevar", "")
            for var_name, override in overrides.items():
                gamevar += f"\n{var_name},{var_name},{override['var_type']},{override['var_value']},,"
            data["gamevar"] = gamevar
        data["abhotupdate_cdn_url"] = cdn_self
        data["cdn_url"] = cdn_self
        data["backup_cdn_url"] = cdn_self
        print(f"[VER] {ip} abhotupdate_cdn_url -> {cdn_self}")
        print(f"[VER] {ip} abhotupdate_check: cache_res")
        return json.dumps(data)
    except Exception as e:
        print(f"[ERROR] modify_ver_response: {e}")
        return response_text

PAGE_SHELL = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LUNAR OFC PROXY</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; }
body {
  min-height: 100vh;
  background: radial-gradient(ellipse at 20% 10%, #1a0b3d 0%, transparent 55%),
              radial-gradient(ellipse at 85% 85%, #0b2a4a 0%, transparent 55%),
              linear-gradient(160deg, #05010f 0%, #0d0526 50%, #05010f 100%);
  color: #e8e6ff;
  overflow-x: hidden;
}
.stars {
  position: fixed; inset: 0; pointer-events: none; z-index: 0;
  background-image:
    radial-gradient(1px 1px at 25px 35px, #fff, transparent),
    radial-gradient(1px 1px at 125px 95px, #cdd6ff, transparent),
    radial-gradient(1.5px 1.5px at 210px 160px, #9db4ff, transparent),
    radial-gradient(1px 1px at 320px 40px, #fff, transparent),
    radial-gradient(1.5px 1.5px at 90px 240px, #b6c4ff, transparent),
    radial-gradient(1px 1px at 400px 200px, #e8ecff, transparent),
    radial-gradient(1px 1px at 260px 300px, #fff, transparent);
  background-size: 460px 340px;
  opacity: .5;
}
.moon {
  position: fixed; top: -90px; right: -90px; width: 340px; height: 340px; z-index: 0;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, #fff8e0, #f0e6c8 45%, #cdbb8d 70%, #b8a16f 100%);
  box-shadow: 0 0 90px 30px rgba(255, 240, 200, .18), inset -18px -12px 40px rgba(120, 100, 60, .5);
  opacity: .9;
}
.moon::after {
  content: ''; position: absolute; inset: 0; border-radius: 50%;
  background: radial-gradient(circle at 30% 40%, transparent 52%, rgba(90, 75, 45, .28) 55%, transparent 62%),
              radial-gradient(circle at 65% 65%, transparent 60%, rgba(90, 75, 45, .25) 63%, transparent 70%);
}
@keyframes drift { from { background-position: 0 0; } to { background-position: -460px -340px; } }
.wrap { position: relative; z-index: 2; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 40px 18px; }
.badge { font-size: 12px; letter-spacing: 5px; color: #9aa4ff; text-transform: uppercase; margin-bottom: 8px; }
h1 {
  font-size: clamp(34px, 7vw, 64px); font-weight: 800; letter-spacing: 4px; text-align: center;
  background: linear-gradient(90deg, #7df9ff, #b48cff, #ff8ad8);
  -webkit-background-clip: text; background-clip: text; color: transparent;
  filter: drop-shadow(0 0 18px rgba(140, 140, 255, .45));
}
.sub { text-align: center; color: #9aa0c8; margin: 6px 0 30px; font-size: 14px; letter-spacing: 2px; }
.card {
  width: 100%; max-width: 560px;
  background: rgba(255, 255, 255, .045);
  border: 1px solid rgba(160, 170, 255, .18);
  border-radius: 18px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, .5), inset 0 1px 0 rgba(255, 255, 255, .06);
  padding: 26px; margin-bottom: 22px;
}
.row { display: flex; align-items: center; flex-wrap: wrap; gap: 12px; padding: 10px 4px; font-size: 15px; border-bottom: 1px solid rgba(160,170,255,.08); }
.row:last-child { border-bottom: none; }
.lbl { color: #9aa0c8; min-width: 120px; letter-spacing: 1px; text-transform: uppercase; font-size: 12px; }
.val { font-weight: 600; word-break: break-all; }
.ok { color: #37f5a5; } .no { color: #ff5d7d; }
h2 { font-size: 16px; letter-spacing: 3px; margin-bottom: 14px; color: #cdd3ff; text-transform: uppercase; }
button {
  width: 100%; padding: 14px; border: none; border-radius: 10px; font-size: 15px; font-weight: 700; letter-spacing: 2px;
  cursor: pointer; color: #05010f; margin-top: 14px;
  background: linear-gradient(90deg, #7df9ff, #b48cff);
  box-shadow: 0 6px 24px rgba(140, 140, 255, .4);
  transition: transform .15s, box-shadow .2s;
}
button:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(140, 140, 255, .55); }
button:disabled { opacity: .4; cursor: not-allowed; }
.hint { font-size: 12px; color: #7f87b8; margin-top: 4px; }
.links { display: flex; flex-direction: column; gap: 10px; margin-top: 14px; }
.btn {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  width: 100%; padding: 13px; border-radius: 10px; text-decoration: none; font-weight: 700; letter-spacing: 1px; font-size: 14px;
  color: #fff; transition: transform .15s, filter .2s;
}
.btn:hover { transform: translateY(-2px); filter: brightness(1.12); }
.btn.yt { background: linear-gradient(90deg, #ff0033, #ff4d6d); box-shadow: 0 6px 24px rgba(255,0,51,.35); }
.btn.tg { background: linear-gradient(90deg, #0088cc, #00b0f0); box-shadow: 0 6px 24px rgba(0,136,204,.35); }
.btn.short { background: linear-gradient(90deg, #7b2dff, #b48cff); box-shadow: 0 6px 24px rgba(123,45,255,.35); }
.msg { display: none; padding: 12px 14px; border-radius: 10px; font-size: 14px; margin-top: 12px; }
.msg.okm { display: block; background: rgba(55,245,165,.08); border: 1px solid rgba(55,245,165,.3); color: #37f5a5; }
.msg.err { display: block; background: rgba(255,93,125,.08); border: 1px solid rgba(255,93,125,.3); color: #ff5d7d; }
.radio-row { display: flex; gap: 8px; flex-wrap: wrap; }
.radio-chip { flex: 1; text-align: center; padding: 9px; border: 1px solid rgba(160,170,255,.25); border-radius: 10px; cursor: pointer; background: rgba(10,6,30,.5); font-size: 12px; letter-spacing: 1px; transition: .15s; }
.radio-chip input { display: none; }
.radio-chip:has(input:checked) { background: rgba(125,249,255,.15); border-color: #7df9ff; color: #7df9ff; }
.switch { position: relative; width: 46px; height: 24px; flex-shrink: 0; display: inline-block; }
.switch input { opacity: 0; width: 0; height: 0; }
.slider { position: absolute; cursor: pointer; inset: 0; background: #2a2550; border-radius: 24px; transition: .2s; }
.slider:before { content: ""; position: absolute; height: 18px; width: 18px; left: 3px; bottom: 3px; background: #8a7bff; border-radius: 50%; transition: .2s; }
.switch input:checked + .slider { background: #4fc3f7; }
.switch input:checked + .slider:before { transform: translateX(22px); }
footer { margin-top: 26px; font-size: 12px; color: #6b73a5; letter-spacing: 2px; }
</style>
</head>
<body>
<div class="stars"></div>
<div class="moon"></div>
<div class="wrap">
  <div class="badge">Elite Configuration Portal</div>
  <h1>LUNAR OFC PROXY</h1>
  <div class="sub">SECURE GATEWAY &middot; IP-AUTHORIZED ACCESS</div>
__CONTENT__
  <footer><i class="fa-solid fa-moon"></i> LUNAR OFC PROXY &middot; v1.1 &middot; <i class="fa-solid fa-shield-halved"></i> FOR AUTHORIZED USE ONLY</footer>
</div>
</body>
</html>"""

STEP_BODY = """<div class="card">
  <h2><i class="fa-solid fa-list-check"></i>&nbsp; Complete Steps</h2>
  <div class="row"><span class="lbl"><i class="fa-brands fa-youtube"></i>&nbsp; Step 1</span><span class="val no" id="s1"><i class="fa-regular fa-circle"></i> Not done</span></div>
  <div class="row"><span class="lbl"><i class="fa-brands fa-telegram"></i>&nbsp; Step 2</span><span class="val no" id="s2"><i class="fa-regular fa-circle"></i> Not done</span></div>
  <div class="row"><span class="lbl"><i class="fa-solid fa-link"></i>&nbsp; Step 3</span><span class="val no" id="s3"><i class="fa-regular fa-circle"></i> Not done</span></div>
  <div class="links">
    <a class="btn yt" href="/open/yt" target="_blank" rel="noopener"><i class="fa-brands fa-youtube"></i>&nbsp; SUBSCRIBE ON YOUTUBE</a>
    <a class="btn tg" href="/open/tg" target="_blank" rel="noopener"><i class="fa-brands fa-telegram"></i>&nbsp; JOIN ON TELEGRAM</a>
    <a class="btn short" href="/open/upload" target="_blank" rel="noopener"><i class="fa-solid fa-upload"></i>&nbsp; COMPLETE DEV UPLOAD</a>
  </div>
  <button id="verifyBtn" type="button" disabled><i class="fa-solid fa-circle-check"></i>&nbsp; I HAVE JOINED &amp; SUBSCRIBED</button>
  <div id="vmsg" class="msg"></div>
</div>
<script>
function setStep(id, done) {
  var el = document.getElementById(id);
  el.innerHTML = done ? '<i class="fa-solid fa-circle-check"></i> Done' : '<i class="fa-regular fa-circle"></i> Not done';
  el.className = 'val ' + (done ? 'ok' : 'no');
}
async function poll() {
  try {
    var r = await fetch('/status');
    var s = await r.json();
    setStep('s1', s.yt);
    setStep('s2', s.tg);
    setStep('s3', s.upload);
    document.getElementById('verifyBtn').disabled = !s.steps_done;
    if (s.verified) window.location.href = '/register-access';
  } catch (e) {}
}
document.getElementById('verifyBtn').addEventListener('click', async function () {
  var m = document.getElementById('vmsg');
  m.className = 'msg';
  m.textContent = 'Verifying...';
  try {
    var r = await fetch('/verify', { method: 'POST' });
    var d = await r.json();
    m.className = 'msg ' + (r.ok ? 'okm' : 'err');
    m.textContent = r.ok ? (d.message || 'Steps completed') : (d.error || 'Verification failed');
    if (r.ok) setTimeout(function () { window.location.href = '/register-access'; }, 600);
  } catch (e) { m.className = 'msg err'; m.textContent = 'Connection error'; }
});
poll();
setInterval(poll, 6000);
</script>"""

REG_BODY = """<div class="card">
  <h2><i class="fa-solid fa-user-lock"></i>&nbsp; Register Access</h2>
  <div id="msg" class="msg"></div>
  <button id="regBtn" type="button"><i class="fa-solid fa-key"></i>&nbsp; REGISTER ACCESS</button>
  <div class="hint"><i class="fa-solid fa-circle-info"></i>&nbsp; This authorizes your IP for the proxy. After registering you will be taken to the authorized page.</div>
</div>
<script>
document.getElementById('regBtn').addEventListener('click', async function () {
  var m = document.getElementById('msg');
  m.className = 'msg';
  m.textContent = 'Registering...';
  try {
    var r = await fetch('/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) });
    var d = await r.json();
    if (r.ok) { window.location.href = '/authorized'; }
    else { m.className = 'msg err'; m.textContent = d.error || 'Registration failed'; }
  } catch (e) { m.className = 'msg err'; m.textContent = 'Connection error'; }
});
</script>"""

AUTH_BODY = """<div class="card">
  <h2><i class="fa-solid fa-shield-halved"></i>&nbsp; IP AUTHORIZED</h2>
  <div class="row"><span class="lbl"><i class="fa-solid fa-fire"></i>&nbsp; Mode</span><span class="val ok">HS CHEST</span></div>
  <div class="row"><span class="lbl"><i class="fa-solid fa-bolt"></i>&nbsp; Speed hack</span><span class="val ok">ENABLED</span></div>
  <div class="row"><span class="lbl"><i class="fa-solid fa-server"></i>&nbsp; IP</span><span class="val">__IP__</span></div>
  <div class="hint"><i class="fa-solid fa-circle-check"></i>&nbsp; Your device is authorized. Now open the game and connect through the proxy — settings are applied automatically.</div>
</div>"""


def render_page(body, ip):
    return PAGE_SHELL.replace("__CONTENT__", body.replace("__IP__", ip or "unknown"))

load_registered()
load_verified()
load_engaged()

app = web.Application()

@web.middleware
async def ip_gate(request, handler):
    path = request.path
    if path in ("/", "/register-access", "/authorized", "/register", "/verify", "/status", "/favicon.ico") or path.startswith("/open/"):
        return await handler(request)
    ip = client_ip(request)
    if not is_registered(ip):
        return web.json_response({"error": "Access denied: your IP is not registered. Open / to authorize your device."}, status=403)
    return await handler(request)

app.middlewares.append(ip_gate)

async def init_session(app):
    connector = TCPConnector(limit=100, ttl_dns_cache=300)
    timeout = ClientTimeout(total=60, connect=10)
    app['session'] = ClientSession(connector=connector, timeout=timeout)

async def cleanup_session(app):
    await app['session'].close()

async def handle_root(request):
    ip = client_ip(request)
    if is_verified(ip):
        return web.Response(status=302, headers={"Location": "/register-access"})
    return web.Response(text=render_page(STEP_BODY, ip), content_type='text/html', charset='utf-8')

async def handle_register_page(request):
    ip = client_ip(request)
    if not is_verified(ip):
        return web.Response(status=302, headers={"Location": "/"})
    if is_registered(ip):
        return web.Response(status=302, headers={"Location": "/authorized"})
    return web.Response(text=render_page(REG_BODY, ip), content_type='text/html', charset='utf-8')

async def handle_authorized(request):
    ip = client_ip(request)
    if not is_registered(ip):
        return web.Response(status=302, headers={"Location": "/"})
    return web.Response(text=render_page(AUTH_BODY, ip), content_type='text/html', charset='utf-8')

async def handle_register(request):
    if not is_verified(client_ip(request)):
        return web.json_response({"error": "Complete the steps first: join & subscribe. Then verify."}, status=403)
    ip = None
    try:
        data = await request.json()
        ip = (data.get("ip") or "").strip()
    except Exception:
        try:
            post = await request.post()
            ip = (post.get("ip") or "").strip()
        except Exception:
            pass
    if not ip:
        ip = client_ip(request)
    if not is_valid_ip(ip):
        return web.json_response({"error": "Invalid IP address."}, status=400)
    register_ip(ip)
    print(f"[AUTH] registered IP: {ip}")
    return web.json_response({"success": True, "message": f"IP {ip} authorized"})

async def handle_verify(request):
    ip = client_ip(request)
    if not steps_done(ip):
        return web.json_response({"error": "Complete ALL steps first: subscribe on YouTube, join on Telegram, and finish the dev upload."}, status=403)
    mark_verified(ip)
    print(f"[AUTH] steps verified: {ip}")
    return web.json_response({"success": True, "message": "Steps completed. IP registration unlocked.", "verified": sorted(_verified)})

async def handle_open_yt(request):
    ip = client_ip(request)
    mark_engaged(ip, "yt")
    print(f"[AUTH] youtube opened: {ip}")
    return web.Response(status=302, headers={"Location": YT_URL})

async def handle_open_tg(request):
    ip = client_ip(request)
    mark_engaged(ip, "tg")
    print(f"[AUTH] telegram opened: {ip}")
    return web.Response(status=302, headers={"Location": TG_URL})

async def handle_open_upload(request):
    ip = client_ip(request)
    mark_engaged(ip, "upload")
    print(f"[AUTH] dev upload opened: {ip}")
    return web.Response(status=302, headers={"Location": DEV_UPLOAD_URL})

async def handle_status(request):
    ip = client_ip(request)
    e = engagement(ip)
    return web.json_response({
        "ip": ip,
        "yt": e["yt"],
        "tg": e["tg"],
        "upload": e["upload"],
        "steps_done": steps_done(ip),
        "verified": is_verified(ip),
        "registered": is_registered(ip),
    })

async def handle_ver_php(request):
    session = request.app['session']
    params = dict(request.query)
    ip = client_ip(request)
    cdn_self = f"http://{request.host}/cdn/live/ABHotUpdates/"
    print(f"[REQUEST] ver.php {ip} {params}")
    try:
        async with session.get(VER_PHP_URL, params=params) as resp:
            text = await resp.text()
            modified = modify_ver_response(text, cdn_self, ip)
            print(f"[RESPONSE] ver.php status: {resp.status}")
            return web.Response(text=modified, content_type='application/json')
    except Exception as e:
        print(f"[ERROR] ver.php: {e}")
        return web.Response(text='Error', status=502)

async def handle_cdn(request):
    session = request.app['session']
    ip = client_ip(request)
    path = request.match_info.get('path', '')

    if not path or path == '/':
        print(f"[CDN] Empty path request")
        return web.Response(text='Not found', status=404)

    print(f"[CDN] {ip} Request: {path}")

    for prefix in ("cdn/live/ABHotUpdates/", "cdn/", "live/ABHotUpdates/"):
        if path.startswith(prefix):
            path = path[len(prefix):]
            break

    upstream = TARGET_BASE_URL
    if not upstream.endswith("/"):
        upstream += "/"

    if "cache_res" in path and "avatar" not in path:
        gz_data = cache_res_data()
        if gz_data is not None:
            print(f"[CDN] {ip} Serving local {SERVE_CACHE_RES}")
            return web.Response(body=gz_data, content_type='application/octet-stream')

    if "fileinfo" in path:
        target_url = upstream + path
        print(f"[CDN] {ip} Proxying fileinfo: {target_url}")
        try:
            async with session.get(target_url) as resp:
                text = await resp.text()
                print(f"[CDN] fileinfo received: {len(text)} bytes")
                patched = patch_fileinfo(text)
                if patched != text:
                    print(f"[CDN] {ip} fileinfo cache_res line patched")
                return web.Response(body=patched.encode(), content_type='binary/octet-stream')
        except Exception as e:
            print(f"[ERROR] fileinfo: {e}")
            return web.Response(text='Error', status=502)

    target_url = upstream + path
    print(f"[CDN] {ip} Proxying: {target_url}")
    try:
        async with session.get(target_url) as resp:
            body = await resp.read()
            print(f"[CDN] Response: {resp.status}, {len(body)} bytes")
            return web.Response(body=body, status=resp.status, content_type=resp.headers.get('content-type', 'application/octet-stream'))
    except Exception as e:
        print(f"[ERROR] cdn: {e}")
        return web.Response(text='Error', status=502)

app.router.add_get('/', handle_root)
app.router.add_get('/register-access', handle_register_page)
app.router.add_get('/authorized', handle_authorized)
app.router.add_post('/register', handle_register)
app.router.add_post('/verify', handle_verify)
app.router.add_get('/open/yt', handle_open_yt)
app.router.add_get('/open/tg', handle_open_tg)
app.router.add_get('/open/upload', handle_open_upload)
app.router.add_get('/status', handle_status)
app.router.add_get('/ver.php', handle_ver_php)
app.router.add_get('/live/ver.php', handle_ver_php)
app.router.add_get('/cdn/live/ABHotUpdates/', handle_cdn)
app.router.add_get('/cdn/live/ABHotUpdates/{path:.*}', handle_cdn)
app.router.add_get('/{path:.*}', handle_cdn)

app.on_startup.append(init_session)
app.on_cleanup.append(cleanup_session)

SERVER_IP = "localhost"

if __name__ == "__main__":
    load_registered()
    load_verified()
    load_engaged()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        SERVER_IP = s.getsockname()[0]
        s.close()
    except Exception:
        SERVER_IP = "127.0.0.1"

    print("[*] LUNAR OFC PROXY")
    print(f"[*] VPS PUBLIC URL: http://{SERVER_IP}:{PORT}")
    print(f"[*] Panel: http://{SERVER_IP}:{PORT}")
    print(f"[*] CDN -> {TARGET_BASE_URL}")
    print(f"[*] ver.php -> {VER_PHP_URL}")
    print(f"[*] Injecting {len(get_overrides())} anti-ban overrides + speed hack (always on)")
    print(f"[*] Mode: HS CHEST ({SERVE_CACHE_RES}) + speed enabled")
    print(f"[*] Authorized IPs: {sorted(_registered) if _registered else 'none — open the page to register'}")
    print(f"[*] Steps verified: {sorted(_verified) if _verified else 'none'}")
    print(f"[*] Verify gate: subscribe {YT_URL} and join {TG_URL}")
    ensure_cache_res_gzip()
    print(f"[*] cache_res: {'loaded' if os.path.exists(os.path.join(BASE_DIR, SERVE_CACHE_RES)) else 'missing'} ({SERVE_CACHE_RES})")
    print("[*] Waiting for requests...")
    web.run_app(app, host="0.0.0.0", port=PORT, access_log=None)
